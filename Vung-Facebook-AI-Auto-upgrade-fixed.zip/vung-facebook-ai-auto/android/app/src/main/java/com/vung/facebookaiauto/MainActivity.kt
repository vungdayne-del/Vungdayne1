package com.vung.facebookaiauto

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Blue = androidx.compose.ui.graphics.Color(0xFF1877F2)
private val Green = androidx.compose.ui.graphics.Color(0xFF16803C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("vung_settings", MODE_PRIVATE)
        // Migrate old plaintext values to AES-GCM values protected by Android Keystore.
        val oldBase = prefs.getString("base_url", "") ?: ""
        val oldToken = prefs.getString("admin_token", "") ?: ""
        if (prefs.getString("base_url_enc", null) == null && oldBase.isNotBlank()) saveEncrypted(this, "base_url_enc", oldBase)
        if (prefs.getString("admin_token_enc", null) == null && oldToken.isNotBlank()) saveEncrypted(this, "admin_token_enc", oldToken)
        prefs.edit().remove("base_url").remove("admin_token").apply()
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = Blue, secondary = androidx.compose.ui.graphics.Color(0xFF7C3AED))
            ) {
                VungApp(
                    initialBaseUrl = loadEncrypted(this, "base_url_enc"),
                    initialAdminToken = loadEncrypted(this, "admin_token_enc"),
                    onSaveConnection = { base, token ->
                        saveEncrypted(this, "base_url_enc", base.trim().trimEnd('/'))
                        saveEncrypted(this, "admin_token_enc", token.trim())
                    }
                )
            }
        }
    }
}

private const val KEY_ALIAS = "vung_facebook_ai_auto_aes_key"

private fun keystoreKey(): SecretKey {
    val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build())
    return generator.generateKey()
}

private fun saveEncrypted(activity: ComponentActivity, name: String, value: String) {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, keystoreKey()) }
    val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
    val payload = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + "." + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    activity.getSharedPreferences("vung_settings", Context.MODE_PRIVATE).edit().putString(name, payload).apply()
}

private fun loadEncrypted(activity: ComponentActivity, name: String): String {
    val payload = activity.getSharedPreferences("vung_settings", Context.MODE_PRIVATE).getString(name, null) ?: return ""
    return try {
        val parts = payload.split(".", limit = 2); require(parts.size == 2)
        val iv = Base64.decode(parts[0], Base64.NO_WRAP); val data = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, keystoreKey(), GCMParameterSpec(128, iv)) }
        String(cipher.doFinal(data), Charsets.UTF_8)
    } catch (_: Exception) { "" }
}

data class PageItem(val id: String, val pageId: String, val name: String, val status: String)
data class JobItem(val id: String, val title: String, val status: String, val pageId: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VungApp(initialBaseUrl: String, initialAdminToken: String, onSaveConnection: (String, String) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var baseUrl by remember { mutableStateOf(initialBaseUrl) }
    var adminToken by remember { mutableStateOf(initialAdminToken) }
    var geminiKey by remember { mutableStateOf("") }
    var pageName by remember { mutableStateOf("") }
    var pageId by remember { mutableStateOf("") }
    var pageToken by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var generatedTitle by remember { mutableStateOf("") }
    var generatedBody by remember { mutableStateOf("") }
    var generatedId by remember { mutableStateOf("") }
    var targetPageId by remember { mutableStateOf("") }
    var scheduleAt by remember { mutableStateOf("") }
    var researchNiche by remember { mutableStateOf("") }
    var researchedTopics by remember { mutableStateOf(listOf<String>()) }
    var monthlyBudget by remember { mutableStateOf("10") }
    var pages by remember { mutableStateOf(listOf<PageItem>()) }
    var jobs by remember { mutableStateOf(listOf<JobItem>()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Nhập địa chỉ backend trong Cài đặt để bắt đầu.") }
    var error by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    fun request(path: String, method: String = "GET", body: JSONObject? = null, needsAuth: Boolean = true): JSONObject {
        val root = baseUrl.trim().trimEnd('/')
        require(root.startsWith("https://") || root.startsWith("http://10.0.2.2") || root.startsWith("http://127.0.0.1")) {
            "Địa chỉ backend phải dùng HTTPS (HTTP chỉ được chấp nhận cho môi trường local)."
        }
        val conn = (URL(root + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 12_000
        conn.readTimeout = 60_000
        conn.setRequestProperty("Accept", "application/json")
        if (needsAuth) conn.setRequestProperty("Authorization", "Bearer $adminToken")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        conn.disconnect()
        val json = try { JSONObject(text) } catch (_: Exception) { JSONObject().put("message", text) }
        if (code !in 200..299) throw IllegalStateException(json.optString("error", "Máy chủ trả về HTTP $code"))
        return json
    }

    fun runAction(action: suspend () -> String) {
        if (busy) return
        busy = true
        error = false
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { action() }
                message = result
                snackbar.showSnackbar(result)
            } catch (e: Exception) {
                error = true
                message = e.message ?: "Có lỗi không xác định."
                snackbar.showSnackbar(message)
            } finally { busy = false }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Vùng Facebook AI Auto", style = MaterialTheme.typography.titleMedium)
                        Text("Điều khiển Fanpage", style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = { runAction {
                        val r = request("/api/health", needsAuth = false)
                        "Backend kết nối thành công · ${r.optString("service", "API")}"
                    } }) { Icon(Icons.Default.CloudDone, contentDescription = "Kiểm tra máy chủ") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val labels = listOf("Tổng quan", "Nội dung", "Fanpage", "Lịch sử", "Cài đặt")
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.AutoAwesome, Icons.Default.Facebook, Icons.Default.History, Icons.Default.Settings)
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(icons[index], contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Card(colors = CardDefaults.cardColors(containerColor = if (error) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (error) Icons.Default.ErrorOutline else Icons.Default.Info, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(message, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            when (tab) {
                0 -> {
                    item { Text("Tổng quan", style = MaterialTheme.typography.headlineSmall) }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard("Fanpage", pages.size.toString(), Icons.Default.Facebook, Modifier.weight(1f))
                            MetricCard("Tác vụ", jobs.size.toString(), Icons.Default.Schedule, Modifier.weight(1f))
                        }
                    }
                    item {
                        Button(onClick = { runAction {
                            val p = request("/api/pages").optJSONArray("pages") ?: JSONArray()
                            pages = (0 until p.length()).map { i -> p.getJSONObject(i).toPage() }
                            val j = request("/api/posts").optJSONArray("jobs") ?: JSONArray()
                            jobs = (0 until j.length()).map { i -> j.getJSONObject(i).toJob() }
                            "Đã cập nhật tổng quan."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(8.dp)); Text("Làm mới dữ liệu")
                        }
                    }
                    item { Text("Tác vụ gần đây", style = MaterialTheme.typography.titleMedium) }
                    items(jobs.take(5)) { JobCard(it) }
                }
                1 -> {
                    item { Text("Tạo nội dung bằng AI", style = MaterialTheme.typography.headlineSmall) }
                    item { OutlinedTextField(topic, { topic = it }, label = { Text("Chủ đề bài viết") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                    item {
                        Button(onClick = { runAction {
                            require(topic.trim().length >= 3) { "Nhập chủ đề dài ít nhất 3 ký tự." }
                            val r = request("/api/ai/generate", "POST", JSONObject().put("topic", topic.trim()))
                            generatedId = r.optString("id")
                            generatedTitle = r.optString("title")
                            generatedBody = r.optString("body")
                            "Đã tạo bản nháp. Hãy kiểm tra nội dung trước khi đăng."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Tạo bài viết")
                        }
                    }
                    if (generatedTitle.isNotBlank()) {
                        item { OutlinedTextField(generatedTitle, { generatedTitle = it }, label = { Text("Tiêu đề") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(generatedBody, { generatedBody = it }, label = { Text("Nội dung") }, modifier = Modifier.fillMaxWidth(), minLines = 5) }
                        item { OutlinedTextField(targetPageId, { targetPageId = it }, label = { Text("Page ID để đăng") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(scheduleAt, { scheduleAt = it }, label = { Text("Lên lịch (ISO, để trống = đăng ngay)") }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("2026-10-20T09:00:00+07:00") }) }
                        item { Button(onClick = { runAction {
                            require(generatedId.isNotBlank()) { "Không tìm thấy ID bản nháp." }
                            request("/api/content/$generatedId", "PUT", JSONObject().put("title", generatedTitle).put("body", generatedBody))
                            "Đã lưu chỉnh sửa bản nháp."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Lưu chỉnh sửa") } }
                        item { Button(onClick = { runAction {
                            require(generatedId.isNotBlank() && targetPageId.isNotBlank()) { "Cần bản nháp và Page ID." }
                            val payload = JSONObject().put("contentId", generatedId).put("pageId", targetPageId.trim())
                            if (scheduleAt.isNotBlank()) payload.put("scheduledAt", scheduleAt.trim())
                            val r = request("/api/posts", "POST", payload)
                            val j = request("/api/posts").optJSONArray("jobs") ?: JSONArray()
                            jobs = (0 until j.length()).map { i -> j.getJSONObject(i).toJob() }
                            "Đã tạo tác vụ đăng bài: ${r.optString("status")}."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Đăng ngay / lên lịch") } }
                    }
                    item { Divider() }
                    item { Text("Nghiên cứu chủ đề đang đáng chú ý", style = MaterialTheme.typography.titleMedium) }
                    item { OutlinedTextField(researchNiche, { researchNiche = it }, label = { Text("Ngách nội dung") }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Khoa học vũ trụ, lịch sử...") }) }
                    item { Button(onClick = { runAction {
                        require(researchNiche.trim().length >= 2) { "Nhập ngách nội dung." }
                        val r=request("/api/topics/research","POST",JSONObject().put("niche",researchNiche.trim()).put("count",8))
                        val arr=r.optJSONArray("ideas")?:JSONArray()
                        researchedTopics=(0 until arr.length()).map { i -> arr.getJSONObject(i).optString("topic") }
                        "Đã nghiên cứu ${researchedTopics.size} ý tưởng."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Tìm ý tưởng bằng AI + web") } }
                    items(researchedTopics) { idea -> Text("• $idea", style = MaterialTheme.typography.bodyMedium) }
                }
                2 -> {
                    item { Text("Quản lý Fanpage", style = MaterialTheme.typography.headlineSmall) }
                    item { OutlinedTextField(pageName, { pageName = it }, label = { Text("Tên Fanpage") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(pageId, { pageId = it }, label = { Text("Page ID") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                    item { OutlinedTextField(pageToken, { pageToken = it }, label = { Text("Page Access Token") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation()) }
                    item {
                        Button(onClick = { runAction {
                            require(pageName.isNotBlank() && pageId.isNotBlank() && pageToken.isNotBlank()) { "Nhập đủ tên Fanpage, Page ID và Page Access Token." }
                            val r = request("/api/pages", "POST", JSONObject().put("name", pageName).put("pageId", pageId).put("accessToken", pageToken))
                            val p = request("/api/pages").optJSONArray("pages") ?: JSONArray()
                            pages = (0 until p.length()).map { i -> p.getJSONObject(i).toPage() }
                            pageToken = ""
                            "Đã kết nối ${r.optJSONObject("page")?.optString("name") ?: pageName}."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                            Icon(Icons.Default.AddLink, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Kiểm tra và thêm Fanpage")
                        }
                    }
                    items(pages) { PageCard(it) }
                    item {
                        OutlinedButton(onClick = { runAction {
                            val p = request("/api/pages").optJSONArray("pages") ?: JSONArray()
                            pages = (0 until p.length()).map { i -> p.getJSONObject(i).toPage() }
                            "Đã tải danh sách Fanpage."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Tải danh sách Fanpage") }
                    }
                }
                3 -> {
                    item { Text("Lịch sử đăng bài", style = MaterialTheme.typography.headlineSmall) }
                    item { Button(onClick = { runAction {
                        val j = request("/api/posts").optJSONArray("jobs") ?: JSONArray()
                        jobs = (0 until j.length()).map { i -> j.getJSONObject(i).toJob() }
                        "Đã tải lịch sử đăng bài."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Làm mới lịch sử") } }
                    items(jobs) { JobCard(it) }
                }
                else -> {
                    item { Text("Cài đặt", style = MaterialTheme.typography.headlineSmall) }
                    item { OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("Địa chỉ Backend HTTPS") }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://api.example.com") }) }
                    item { OutlinedTextField(adminToken, { adminToken = it }, label = { Text("Admin API Token") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation()) }
                    item {
                        Button(onClick = {
                            onSaveConnection(baseUrl, adminToken)
                            message = "Đã lưu cấu hình kết nối trên thiết bị."
                            error = false
                        }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                            Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Lưu cấu hình kết nối")
                        }
                    }
                    Divider()
                    item { Text("Gemini API", style = MaterialTheme.typography.titleMedium) }
                    item { OutlinedTextField(geminiKey, { geminiKey = it }, label = { Text("Gemini API key mới") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation()) }
                    item {
                        Button(onClick = { runAction {
                            require(geminiKey.trim().length >= 10) { "API key có vẻ chưa hợp lệ." }
                            request("/api/config/gemini", "PUT", JSONObject().put("apiKey", geminiKey.trim()))
                            geminiKey = ""
                            "Đã lưu Gemini API key trên máy chủ."
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Lưu / thay API key") }
                    }
                    item {
                        OutlinedButton(onClick = { runAction {
                            val r = request("/api/health", needsAuth = false)
                            "Backend OK · ${r.optString("time")}"
                        } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                            Icon(Icons.Default.CloudDone, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Kiểm tra kết nối backend")
                        }
                    }
                    item { Divider() }
                    item { Text("Tự động hóa", style = MaterialTheme.typography.titleMedium) }
                    item { Text("Tự đăng chỉ chạy khi bạn bật rõ ràng và cung cấp Page ID. Đây là nút có thể đăng bài thật, không phải công tắc trang trí.", style = MaterialTheme.typography.bodySmall) }
                    item { Button(onClick = { runAction {
                        require(targetPageId.isNotBlank()) { "Vào tab Nội dung và nhập Page ID đích trước." }
                        request("/api/automation/auto_publish", "PUT", JSONObject().put("enabled", true).put("settings", JSONObject().put("pageIds", JSONArray().put(targetPageId.trim())).put("requireApproval", false)))
                        "Đã bật tự đăng cho Page ${targetPageId.trim()}."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Bật tự đăng AI cho Page ID đã nhập") } }
                    item { OutlinedButton(onClick = { runAction {
                        request("/api/automation/auto_publish", "PUT", JSONObject().put("enabled", false).put("settings", JSONObject()))
                        "Đã tắt tự đăng AI."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Tắt tự đăng AI") } }
                    item { Button(onClick = { runAction {
                        request("/api/automation/auto_reply_comments", "PUT", JSONObject().put("enabled", true).put("settings", JSONObject()))
                        "Đã bật trả lời bình luận tự động. Các trường hợp nhạy cảm được chuyển người thật xử lý."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Bật trả lời bình luận tự động") } }
                    item { OutlinedButton(onClick = { runAction {
                        request("/api/automation/auto_reply_comments", "PUT", JSONObject().put("enabled", false).put("settings", JSONObject()))
                        "Đã tắt trả lời bình luận tự động."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Tắt trả lời bình luận tự động") } }
                    item { OutlinedTextField(monthlyBudget, { monthlyBudget = it }, label = { Text("Ngân sách AI tháng (USD ước tính)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) }
                    item { Button(onClick = { runAction {
                        val amount = monthlyBudget.toDoubleOrNull() ?: throw IllegalArgumentException("Ngân sách không hợp lệ.")
                        require(amount > 0) { "Ngân sách phải lớn hơn 0." }
                        request("/api/automation/budget_guard", "PUT", JSONObject().put("enabled", true).put("settings", JSONObject().put("monthlyBudgetUsd", amount).put("estimatedCostPerCallUsd", 0.002)))
                        "Đã bật giới hạn ngân sách AI ước tính: \$${amount}/tháng."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Bật giới hạn ngân sách AI") } }
                    item { OutlinedButton(onClick = { runAction {
                        request("/api/automation/budget_guard", "PUT", JSONObject().put("enabled", false).put("settings", JSONObject()))
                        "Đã tắt giới hạn ngân sách AI."
                    } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Tắt giới hạn ngân sách AI") } }
                    item { Text("Thông tin bảo mật: URL backend và Admin API Token được mã hóa bằng Android Keystore trên thiết bị. Không dùng HTTP công khai; chỉ dùng HTTPS.", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = Blue)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium)
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun PageCard(page: PageItem) {
    Card {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Facebook, contentDescription = null, tint = Blue)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(page.name, style = MaterialTheme.typography.titleSmall)
                Text("Page ID: ${page.pageId}", style = MaterialTheme.typography.bodySmall)
            }
            Text(page.status, color = if (page.status == "connected") Green else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun JobCard(job: JobItem) {
    Card {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (job.status == "published") Icons.Default.CheckCircle else Icons.Default.Schedule, contentDescription = null,
                tint = if (job.status == "published") Green else Blue)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(job.title.ifBlank { "Bài đăng ${job.id.take(8)}" }, style = MaterialTheme.typography.titleSmall)
                Text("Fanpage: ${job.pageId} · ${job.status}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun JSONObject.toPage() = PageItem(
    id = optString("id"), pageId = optString("pageId"), name = optString("name"),
    status = optString("status", "unknown")
)
private fun JSONObject.toJob() = JobItem(
    id = optString("id"), title = optString("title"), status = optString("status"),
    pageId = optString("pageId")
)
