# Changelog

## 2.0.0 upgrade
- Added startup SQL migrations and fixed Docker image migration packaging.
- Added Gemini topic research with Google Search grounding and source URL collection.
- Added encrypted Meta OAuth state, token exchange, Page sync, and signed webhook validation.
- Added text, image URL, and video URL publishing paths; delayed and bulk scheduling; cancel/retry controls.
- Added content editing, topic/content duplicate fingerprints, and unique topic index.
- Added page insights cache, daily/weekly reports, activity logs, automation settings, AI estimated usage/budget guard, A/B test records.
- Added comment classification, optional AI replies with escalation for selected sensitive cases, Messenger inbox sync and send endpoint.
- Added Android Keystore AES-GCM storage for backend URL and admin token; added draft editing, schedule/publish, topic research and automation controls.
- Added automated repository contract tests.

## Known external prerequisites
Meta permissions/app review, webhook subscription, public HTTPS media URLs, server/VPS uptime, and actual provider credentials remain deployment requirements. The build/test environment in this session had no installed npm dependencies and network installation timed out, so full TypeScript dependency type-check and Android Gradle build could not be executed here. Syntax transpilation and repository tests passed.
