import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '..');
test('automation migration includes reporting, comments, inbox, budget and media fields', () => {
  const sql = readFileSync(resolve(root, 'migrations/002_automation.sql'), 'utf8');
  for (const fragment of ['topic_ideas', 'page_insights_cache', 'automation_rules', 'comment_events', 'inbox_events', 'ab_tests', 'ai_usage', 'media_type', 'media_url']) assert.ok(sql.includes(fragment), `missing ${fragment}`);
});
test('API includes research, bulk publishing, insights, webhook and Messenger reply', () => {
  const src = readFileSync(resolve(root, 'src/routes.ts'), 'utf8');
  for (const fragment of ["/api/topics/research", "/api/posts/bulk", "/api/insights/:pageId", "/api/webhook/meta", "/api/inbox/:id/reply", "/api/automation/:key", "/api/reports/daily"]) assert.ok(src.includes(fragment), `missing ${fragment}`);
});
test('Docker image includes SQL migrations used by startup migration runner', () => {
  const dockerfile = readFileSync(resolve(root, 'Dockerfile'), 'utf8');
  assert.match(dockerfile, /COPY migrations \.\/migrations/);
  assert.match(dockerfile, /COPY --from=build \/app\/migrations \.\/migrations/);
  assert.ok(existsSync(resolve(root, 'migrations/001_init.sql')));
});
