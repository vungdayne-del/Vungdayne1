import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

test('SHA-256 fingerprints are stable for normalized content', () => {
  const normalize = s => s.trim().replace(/\s+/g, ' ').toLowerCase();
  const a = crypto.createHash('sha256').update(normalize('  Hello   World ')).digest('hex');
  const b = crypto.createHash('sha256').update(normalize('hello world')).digest('hex');
  assert.equal(a, b);
});

test('generated ids are UUIDs', () => {
  assert.match(crypto.randomUUID(), /^[0-9a-f-]{36}$/);
});
