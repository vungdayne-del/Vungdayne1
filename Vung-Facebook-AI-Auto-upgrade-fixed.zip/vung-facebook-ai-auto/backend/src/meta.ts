import { decryptSecret } from './security.js';

const graphVersion = process.env.META_GRAPH_VERSION ?? 'v23.0';
const graphBase = `https://graph.facebook.com/${graphVersion}`;

export async function getPageInfo(pageId: string, token: string) {
  const url = new URL(`${graphBase}/${encodeURIComponent(pageId)}`);
  url.searchParams.set('fields', 'id,name,tasks');
  url.searchParams.set('access_token', token);
  const response = await fetch(url, { signal: AbortSignal.timeout(15_000) });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Meta API trả về HTTP ${response.status}`);
  return data;
}

export async function publishText(pageId: string, encryptedToken: string, message: string) {
  const token = decryptSecret(encryptedToken);
  const response = await fetch(`${graphBase}/${encodeURIComponent(pageId)}/feed`, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ message, access_token: token }),
    signal: AbortSignal.timeout(20_000)
  });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Meta API trả về HTTP ${response.status}`);
  return data as { id: string };
}

export function metaOAuthStart(state: string) {
  const appId = process.env.META_APP_ID;
  const redirect = process.env.META_REDIRECT_URI;
  if (!appId || !redirect) throw new Error('Thiếu META_APP_ID hoặc META_REDIRECT_URI.');
  const url = new URL(`https://www.facebook.com/${graphVersion}/dialog/oauth`);
  url.searchParams.set('client_id', appId);
  url.searchParams.set('redirect_uri', redirect);
  url.searchParams.set('state', state);
  url.searchParams.set('scope', 'pages_show_list,pages_manage_posts,pages_read_engagement,pages_manage_metadata,pages_read_user_content,pages_messaging');
  return url.toString();
}


export async function publishPhoto(pageId: string, encryptedToken: string, message: string, imageUrl: string) {
  const token = decryptSecret(encryptedToken);
  const url = new URL(`${graphBase}/${encodeURIComponent(pageId)}/photos`);
  url.searchParams.set('url', imageUrl); url.searchParams.set('message', message); url.searchParams.set('access_token', token);
  const response = await fetch(url, { method: 'POST', signal: AbortSignal.timeout(45000) });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Meta photo API HTTP ${response.status}`);
  return data as { id: string; post_id?: string };
}

export async function getPageInsights(pageId: string, encryptedToken: string, since: string, until: string) {
  const token = decryptSecret(encryptedToken);
  const url = new URL(`${graphBase}/${encodeURIComponent(pageId)}/insights`);
  url.searchParams.set('metric', 'page_impressions,page_engaged_users,page_post_engagements,page_follows');
  url.searchParams.set('period', 'day'); url.searchParams.set('since', since); url.searchParams.set('until', until); url.searchParams.set('access_token', token);
  const response = await fetch(url, { signal: AbortSignal.timeout(25000) });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Meta insights API HTTP ${response.status}`);
  return data;
}

export async function replyToComment(commentId: string, encryptedToken: string, message: string) {
  const token = decryptSecret(encryptedToken);
  const response = await fetch(`${graphBase}/${encodeURIComponent(commentId)}/comments`, {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ message, access_token: token }), signal: AbortSignal.timeout(20000)
  });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Meta comment API HTTP ${response.status}`);
  return data;
}


export async function publishVideo(pageId: string, encryptedToken: string, description: string, videoUrl: string) {
  const token = decryptSecret(encryptedToken);
  const response = await fetch(`${graphBase}/${encodeURIComponent(pageId)}/videos`, {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ file_url: videoUrl, description, access_token: token }),
    signal: AbortSignal.timeout(120000)
  });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Meta video API HTTP ${response.status}`);
  return data as { id: string; post_id?: string };
}


export async function sendMessengerMessage(pageId: string, encryptedToken: string, recipientId: string, message: string) {
  const token=decryptSecret(encryptedToken);
  const response=await fetch(`${graphBase}/${encodeURIComponent(pageId)}/messages`,{
    method:'POST',headers:{'content-type':'application/json'},
    body:JSON.stringify({recipient:{id:recipientId},message:{text:message},messaging_type:'RESPONSE',access_token:token}),signal:AbortSignal.timeout(20000)
  });
  const data=await response.json() as any; if(!response.ok) throw new Error(data?.error?.message??`Messenger API HTTP ${response.status}`); return data;
}
