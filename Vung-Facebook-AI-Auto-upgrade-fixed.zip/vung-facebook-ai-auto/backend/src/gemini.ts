import { pool } from './db.js';
import { decryptSecret } from './security.js';

async function getGeminiKey(): Promise<string> {
  const result = await pool.query('SELECT encrypted_value FROM app_config WHERE config_key=$1', ['gemini_api_key']);
  if (result.rowCount) return decryptSecret(result.rows[0].encrypted_value);
  const envKey = process.env.GEMINI_API_KEY;
  if (!envKey) throw new Error('Chưa cấu hình Gemini API key trong Cài đặt hoặc backend/.env.');
  return envKey;
}

export async function generateContent(topic: string, style = 'rõ ràng, hấp dẫn, có nguồn kiểm chứng') {
  const key = await getGeminiKey();
  const model = process.env.GEMINI_MODEL ?? 'gemini-2.5-flash';
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: 'Bạn là trợ lý biên tập nội dung Facebook bằng tiếng Việt. Không bịa nguồn. Nếu không có dữ liệu tìm kiếm trực tiếp, hãy nêu rõ điều cần kiểm chứng. Trả lời ngắn gọn, có tiêu đề và nội dung.' }] },
      contents: [{ role: 'user', parts: [{ text: `Tạo một bài Facebook về chủ đề: ${topic}\nPhong cách: ${style}\nTrả về JSON với các trường title, body, hashtags, sources (mảng URL nếu có nguồn đáng tin cậy; nếu không, mảng rỗng).` }] }],
      generationConfig: { responseMimeType: 'application/json', temperature: 0.7 }
    }),
    signal: AbortSignal.timeout(45_000)
  });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Gemini API trả về HTTP ${response.status}`);
  const text = data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text ?? '').join('') ?? '';
  if (!text) throw new Error('Gemini không trả về nội dung.');
  try { return JSON.parse(text); }
  catch { return { title: topic, body: text, hashtags: [], sources: [] }; }
}


export async function researchTopics(niche: string, count = 8) {
  const key = await getGeminiKey();
  const model = process.env.GEMINI_MODEL ?? 'gemini-2.5-flash';
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: 'Bạn là biên tập viên nghiên cứu. Chỉ đề xuất chủ đề có giá trị thông tin, không giật tít sai lệch. Dùng tìm kiếm web để tìm nguồn và xu hướng; phân biệt sự kiện đã xác minh với giả thuyết.' }] },
      contents: [{ role: 'user', parts: [{ text: `Nghiên cứu các chủ đề Facebook tiếng Việt đang đáng chú ý trong ngách: ${niche}. Đề xuất tối đa ${Math.min(15, Math.max(1, count))} ý tưởng khác nhau, có lý do, điểm tiềm năng 0-100 và URL nguồn. Trả JSON: {ideas:[{topic,rationale,score,sources:[url]}]}.` }] }],
      tools: [{ google_search: {} }], generationConfig: { responseMimeType: 'application/json', temperature: 0.5 }
    }), signal: AbortSignal.timeout(60000)
  });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message ?? `Gemini research HTTP ${response.status}`);
  const txt = data?.candidates?.[0]?.content?.parts?.map((x: any) => x.text ?? '').join('') ?? '';
  if (!txt) throw new Error('Gemini không trả về kết quả nghiên cứu.');
  let parsed: any;
  try { parsed = JSON.parse(txt); } catch { throw new Error('Gemini trả về JSON không hợp lệ khi nghiên cứu chủ đề.'); }
  const grounding = (data?.candidates?.[0]?.groundingMetadata?.groundingChunks ?? []).map((x: any) => x.web?.uri).filter(Boolean);
  return (Array.isArray(parsed.ideas) ? parsed.ideas : []).slice(0, count).map((x: any) => ({
    topic: String(x.topic ?? '').slice(0, 300), rationale: String(x.rationale ?? '').slice(0, 1000),
    score: Math.max(0, Math.min(100, Number(x.score) || 0)),
    sources: [...new Set([...(Array.isArray(x.sources) ? x.sources : []), ...grounding])].filter((u: any) => typeof u === 'string' && /^https?:\/\//.test(u)).slice(0, 10)
  })).filter((x: any) => x.topic.length >= 3);
}


export async function generateCommentReply(comment: string, pageContext = 'Fanpage') {
  const key=await getGeminiKey(); const model=process.env.GEMINI_MODEL??'gemini-2.5-flash';
  const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,{
    method:'POST',headers:{'content-type':'application/json'},
    body:JSON.stringify({systemInstruction:{parts:[{text:'Bạn là quản trị viên Fanpage Việt Nam. Trả lời bình luận ngắn gọn, lịch sự, không bịa thông tin, không xin dữ liệu cá nhân, không hứa hẹn điều chưa chắc chắn. Nếu bình luận là khiếu nại nghiêm trọng, pháp lý, y tế, tài chính hoặc nội dung nhạy cảm thì trả lời đúng chuỗi NEED_HUMAN để chuyển người thật xử lý.'}]},
      contents:[{role:'user',parts:[{text:`Fanpage: ${pageContext}\nBình luận: ${comment}\nChỉ trả lời nội dung phản hồi, tối đa 500 ký tự.`}]}],generationConfig:{temperature:0.2,maxOutputTokens:250}}),signal:AbortSignal.timeout(30000)
  });
  const data=await response.json() as any; if(!response.ok) throw new Error(data?.error?.message??`Gemini reply HTTP ${response.status}`);
  return String(data?.candidates?.[0]?.content?.parts?.map((x:any)=>x.text??'').join('')??'').trim().slice(0,1000);
}
