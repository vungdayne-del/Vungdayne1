import crypto from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const configured = process.env.ADMIN_API_TOKEN;
  const header = req.header('authorization') ?? '';
  if (!configured || configured.length < 32) {
    return res.status(503).json({ error: 'ADMIN_API_TOKEN chưa được cấu hình an toàn trên máy chủ.' });
  }
  const supplied = header.startsWith('Bearer ') ? header.slice(7) : '';
  const a = Buffer.from(configured);
  const b = Buffer.from(supplied);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: 'Không được phép truy cập. Kiểm tra Admin API Token.' });
  }
  next();
}

function encryptionKey(): Buffer {
  const hex = process.env.ENCRYPTION_KEY ?? '';
  if (!/^[0-9a-fA-F]{64}$/.test(hex)) {
    throw new Error('ENCRYPTION_KEY phải là 64 ký tự hex (32 byte).');
  }
  return Buffer.from(hex, 'hex');
}

export function encryptSecret(value: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, encrypted].map(v => v.toString('base64')).join('.');
}

export function decryptSecret(payload: string): string {
  const [ivB64, tagB64, dataB64] = payload.split('.');
  if (!ivB64 || !tagB64 || dataB64 === undefined) throw new Error('Dữ liệu mã hóa không hợp lệ.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey(), Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}

export function fingerprint(value: string): string {
  return crypto.createHash('sha256').update(value.trim().replace(/\s+/g, ' ').toLowerCase()).digest('hex');
}
