import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { router } from './routes.js';
import { startWorker } from './worker.js';
import { pool } from './db.js';
import { readdir, readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
app.disable('x-powered-by');
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') ?? false }));
app.use(express.json({ limit: '2mb', verify: (req, _res, buf) => { (req as any).rawBody = Buffer.from(buf); } }));
app.use(router);

const port = Number(process.env.PORT ?? 8080);
const here = dirname(fileURLToPath(import.meta.url));
async function migrate() {
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())');
  const dir = join(here, '../migrations');
  const files = (await readdir(dir)).filter(x => /^\d+_.*\.sql$/.test(x)).sort();
  for (const name of files) {
    const exists = await pool.query('SELECT 1 FROM schema_migrations WHERE name=$1', [name]);
    if (exists.rowCount) continue;
    const sql = await readFile(join(dir, name), 'utf8');
    const client = await pool.connect();
    try { await client.query('BEGIN'); await client.query(sql); await client.query('INSERT INTO schema_migrations(name) VALUES($1)', [name]); await client.query('COMMIT'); }
    catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  }
}
const server = app.listen(port, async () => {
  try { await migrate(); console.log(`Vung Facebook AI Auto API listening on ${port}`); startWorker(); }
  catch (e) { console.error('Startup migration failed:', e); process.exit(1); }
});

async function shutdown() {
  server.close();
  await pool.end();
  process.exit(0);
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
