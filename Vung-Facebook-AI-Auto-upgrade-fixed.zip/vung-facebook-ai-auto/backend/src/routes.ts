import crypto from 'node:crypto';
import { Router } from 'express';
import { pool } from './db.js';
import { encryptSecret, decryptSecret, fingerprint } from './security.js';
import { requireAdmin } from './security.js';
import { generateContent, researchTopics, generateCommentReply } from './gemini.js';
import { getPageInfo, metaOAuthStart, getPageInsights, replyToComment, sendMessengerMessage } from './meta.js';
import { publishQueue } from './queue.js';

export const router = Router();

async function assertAiBudget() {
  const rule = await pool.query("SELECT settings FROM automation_rules WHERE rule_key='budget_guard' AND enabled=true");
  if (!rule.rowCount) return;
  const settings = rule.rows[0].settings ?? {};
  const budget = Number(settings.monthlyBudgetUsd);
  const costPerCall = Number(settings.estimatedCostPerCallUsd ?? process.env.AI_ESTIMATED_COST_PER_CALL_USD ?? 0);
  if (!(budget > 0) || !(costPerCall >= 0)) return;
  const spent = await pool.query(`SELECT COALESCE(SUM(estimated_cost),0)::float AS total FROM ai_usage WHERE created_at >= date_trunc('month',NOW())`);
  if (Number(spent.rows[0].total) + costPerCall > budget) throw new Error('Đã chạm ngưỡng ngân sách AI ước tính; tác vụ bị tạm dừng. Kiểm tra giá và usage thực tế của nhà cung cấp.');
}
async function recordAiUsage(operation: string) {
  const rule = await pool.query("SELECT settings FROM automation_rules WHERE rule_key='budget_guard' AND enabled=true");
  const configured = rule.rowCount ? Number(rule.rows[0].settings?.estimatedCostPerCallUsd) : NaN;
  const cost = Math.max(0, Number.isFinite(configured) ? configured : Number(process.env.AI_ESTIMATED_COST_PER_CALL_USD ?? 0));
  await pool.query('INSERT INTO ai_usage(provider,operation,estimated_cost,units) VALUES($1,$2,$3,1)', ['gemini',operation,cost]);
}

async function enqueueAutoPublish(contentId: string) {
  const rule = await pool.query("SELECT settings FROM automation_rules WHERE rule_key='auto_publish' AND enabled=true");
  if (!rule.rowCount) return [];
  const settings = rule.rows[0].settings ?? {};
  const pageIds = Array.isArray(settings.pageIds) ? [...new Set(settings.pageIds.map((x: unknown) => String(x)))].slice(0, 50) : [];
  if (!pageIds.length || settings.requireApproval !== false) return [];
  const pages = await pool.query('SELECT page_id FROM social_pages WHERE page_id=ANY($1::text[]) AND is_active=true', [pageIds]);
  const jobs = [];
  for (const page of pages.rows) {
    const id = crypto.randomUUID();
    await pool.query("INSERT INTO publishing_jobs(id,content_id,page_id,status) VALUES($1,$2,$3,'queued')", [id, contentId, page.page_id]);
    await publishQueue.add('publish', { jobId: id }, { jobId: id, attempts: 3, backoff: { type: 'exponential', delay: 5000 }, removeOnComplete: 1000, removeOnFail: 2000 });
    jobs.push({ id, pageId: page.page_id });
  }
  return jobs;
}

router.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, service: 'Vung Facebook AI Auto', time: new Date().toISOString() });
  } catch {
    res.status(503).json({ ok: false, error: 'Database chưa sẵn sàng.' });
  }
});

router.use('/api', (req, res, next) => {
  if (req.path === '/health' || req.path === '/oauth/meta/callback' || req.path.startsWith('/webhook/meta')) return next();
  return requireAdmin(req, res, next);
});

router.get('/api/config', async (_req, res) => {
  const result = await pool.query('SELECT config_key, updated_at FROM app_config ORDER BY config_key');
  res.json({ configs: result.rows.map(r => ({ key: r.config_key, configured: true, updatedAt: r.updated_at })) });
});

router.put('/api/config/gemini', async (req, res) => {
  const key = String(req.body?.apiKey ?? '').trim();
  if (key.length < 10 || key.length > 500) return res.status(400).json({ error: 'API key không hợp lệ.' });
  try {
    await pool.query(
      `INSERT INTO app_config(config_key, encrypted_value) VALUES($1,$2)
       ON CONFLICT(config_key) DO UPDATE SET encrypted_value=EXCLUDED.encrypted_value, updated_at=NOW()`,
      ['gemini_api_key', encryptSecret(key)]
    );
    res.json({ ok: true, message: 'Đã lưu Gemini API key an toàn trên máy chủ.' });
  } catch (e) {
    res.status(500).json({ error: e instanceof Error ? e.message : 'Không thể lưu key.' });
  }
});

router.get('/api/pages', async (_req, res) => {
  const result = await pool.query(
    `SELECT id, page_id AS "pageId", name, is_active AS active, connection_status AS status, last_checked_at AS "lastCheckedAt"
     FROM social_pages ORDER BY name`
  );
  res.json({ pages: result.rows });
});

router.post('/api/pages', async (req, res) => {
  const pageId = String(req.body?.pageId ?? '').trim();
  const name = String(req.body?.name ?? '').trim();
  const token = String(req.body?.accessToken ?? '').trim();
  if (!pageId || !name || token.length < 10) return res.status(400).json({ error: 'Cần Page ID, tên Fanpage và Page Access Token hợp lệ.' });
  try {
    const info = await getPageInfo(pageId, token);
    const result = await pool.query(
      `INSERT INTO social_pages(page_id,name,encrypted_access_token,connection_status,last_checked_at)
       VALUES($1,$2,$3,'connected',NOW())
       ON CONFLICT(page_id) DO UPDATE SET name=EXCLUDED.name, encrypted_access_token=EXCLUDED.encrypted_access_token,
       connection_status='connected',last_checked_at=NOW(),updated_at=NOW()
       RETURNING id,page_id AS "pageId",name,is_active AS active,connection_status AS status`,
      [pageId, String(info.name ?? name), encryptSecret(token)]
    );
    res.status(201).json({ page: result.rows[0], message: 'Fanpage đã kết nối.' });
  } catch (e) {
    res.status(400).json({ error: e instanceof Error ? e.message : 'Không thể xác thực Fanpage.' });
  }
});

router.post('/api/pages/:id/check', async (req, res) => {
  try {
    const found = await pool.query('SELECT page_id, encrypted_access_token FROM social_pages WHERE id=$1', [req.params.id]);
    if (!found.rowCount) return res.status(404).json({ error: 'Không tìm thấy Fanpage.' });
    const { decryptSecret } = await import('./security.js');
    const info = await getPageInfo(found.rows[0].page_id, decryptSecret(found.rows[0].encrypted_access_token));
    await pool.query(`UPDATE social_pages SET name=$2,connection_status='connected',last_checked_at=NOW(),updated_at=NOW() WHERE id=$1`, [req.params.id, info.name]);
    res.json({ ok: true, name: info.name, tasks: info.tasks ?? [] });
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Không thể kiểm tra kết nối.';
    await pool.query(`UPDATE social_pages SET connection_status='error',last_checked_at=NOW() WHERE id=$1`, [req.params.id]);
    res.status(400).json({ error: message });
  }
});

router.post('/api/ai/generate', async (req, res) => {
  const topic = String(req.body?.topic ?? '').trim();
  const style = String(req.body?.style ?? 'rõ ràng, hấp dẫn').trim();
  if (topic.length < 3 || topic.length > 1000) return res.status(400).json({ error: 'Chủ đề phải từ 3 đến 1000 ký tự.' });
  try {
    await assertAiBudget();
    const generated = await generateContent(topic, style);
    await recordAiUsage('generate_content');
    const body = String(generated.body ?? '').trim();
    const title = String(generated.title ?? topic).trim();
    if (!body) return res.status(502).json({ error: 'AI không tạo được nội dung.' });
    const id = crypto.randomUUID();
    const fp = fingerprint(`${title}\n${body}`);
    await pool.query(
      `INSERT INTO content_items(id,topic,title,body,status,source_references,fingerprint)
       VALUES($1,$2,$3,$4,'draft',$5,$6)
       ON CONFLICT(fingerprint) DO UPDATE SET updated_at=NOW()
       RETURNING id`,
      [id, topic, title, body, JSON.stringify(Array.isArray(generated.sources) ? generated.sources : []), fp]
    );
    const saved = await pool.query('SELECT id FROM content_items WHERE fingerprint=$1', [fp]);
    const autoJobs = await enqueueAutoPublish(saved.rows[0].id);
    res.json({ id: saved.rows[0].id, topic, title, body, hashtags: generated.hashtags ?? [], sources: generated.sources ?? [], status: autoJobs.length ? 'queued_for_auto_publish' : 'draft', autoJobs });
  } catch (e) {
    res.status(502).json({ error: e instanceof Error ? e.message : 'Lỗi khi tạo nội dung AI.' });
  }
});

router.patch('/api/content/:id/media', async (req,res) => {
  const type=String(req.body?.mediaType ?? 'text'); const url=String(req.body?.mediaUrl ?? '').trim();
  if (!['text','image','video'].includes(type)) return res.status(400).json({error:'mediaType chỉ nhận text, image hoặc video.'});
  if (type !== 'text') { try { const u=new URL(url); if (u.protocol !== 'https:') throw new Error(); } catch { return res.status(400).json({error:'Media URL phải là HTTPS công khai để Meta truy cập được.'}); } }
  const r=await pool.query(`UPDATE content_items SET media_type=$2,media_url=$3,image_url=CASE WHEN $2='image' THEN $3 ELSE NULL END,updated_at=NOW() WHERE id=$1 RETURNING id,title,media_type AS "mediaType",media_url AS "mediaUrl"`,[req.params.id,type,type==='text'?null:url]);
  if (!r.rowCount) return res.status(404).json({error:'Không tìm thấy nội dung.'});
  res.json({content:r.rows[0],note:'Chỉ lưu URL; máy chủ không tải file từ URL tuỳ ý. Đảm bảo bạn có quyền sử dụng media.'});
});

router.post('/api/posts', async (req, res) => {
  const contentId = String(req.body?.contentId ?? '');
  const pageId = String(req.body?.pageId ?? '');
  const scheduledAt = req.body?.scheduledAt ? new Date(req.body.scheduledAt) : null;
  if (!contentId || !pageId || (scheduledAt && Number.isNaN(scheduledAt.getTime()))) {
    return res.status(400).json({ error: 'Cần contentId, pageId và thời gian hợp lệ nếu lên lịch.' });
  }
  const content = await pool.query('SELECT id FROM content_items WHERE id=$1', [contentId]);
  const page = await pool.query('SELECT page_id FROM social_pages WHERE page_id=$1 AND is_active=true', [pageId]);
  if (!content.rowCount || !page.rowCount) return res.status(404).json({ error: 'Không tìm thấy bài viết hoặc Fanpage đang hoạt động.' });
  const jobId = crypto.randomUUID();
  await pool.query(
    `INSERT INTO publishing_jobs(id,content_id,page_id,scheduled_at,status) VALUES($1,$2,$3,$4,$5)`,
    [jobId, contentId, pageId, scheduledAt, scheduledAt && scheduledAt.getTime() > Date.now() ? 'scheduled' : 'queued']
  );
  if (!scheduledAt || scheduledAt.getTime() <= Date.now()) {
    await publishQueue.add('publish', { jobId }, { jobId, attempts: 3, backoff: { type: 'exponential', delay: 5000 }, removeOnComplete: 1000, removeOnFail: 2000 });
  } else {
    const delay = Math.max(0, scheduledAt.getTime() - Date.now());
    await publishQueue.add('publish', { jobId }, { jobId, delay, attempts: 3, backoff: { type: 'exponential', delay: 5000 }, removeOnComplete: 1000, removeOnFail: 2000 });
  }
  res.status(201).json({ id: jobId, status: scheduledAt && scheduledAt.getTime() > Date.now() ? 'scheduled' : 'queued' });
});

router.get('/api/posts', async (_req, res) => {
  const result = await pool.query(
    `SELECT j.id,j.page_id AS "pageId",j.status,j.scheduled_at AS "scheduledAt",j.facebook_post_id AS "facebookPostId",
      j.error_message AS "errorMessage",j.attempts,c.title,c.topic,j.created_at AS "createdAt"
     FROM publishing_jobs j JOIN content_items c ON c.id=j.content_id ORDER BY j.created_at DESC LIMIT 200`
  );
  res.json({ jobs: result.rows });
});

router.post('/api/posts/:id/publish', async (req, res) => {
  const found = await pool.query('SELECT id,page_id,status FROM publishing_jobs WHERE id=$1', [req.params.id]);
  if (!found.rowCount) return res.status(404).json({ error: 'Không tìm thấy tác vụ.' });
  if (found.rows[0].status === 'published') return res.status(409).json({ error: 'Bài đã đăng thành công, không đăng lại.' });
  await pool.query(`UPDATE publishing_jobs SET status='queued',error_message=NULL,updated_at=NOW() WHERE id=$1`, [req.params.id]);
  await publishQueue.add('publish', { jobId: req.params.id }, { jobId: `${req.params.id}-manual-${Date.now()}`, attempts: 1 });
  res.json({ ok: true, status: 'queued' });
});

router.get('/api/reports/overview', async (_req, res) => {
  const [pages, jobs, logs] = await Promise.all([
    pool.query('SELECT COUNT(*)::int AS total FROM social_pages WHERE is_active=true'),
    pool.query(`SELECT status,COUNT(*)::int AS count FROM publishing_jobs GROUP BY status`),
    pool.query(`SELECT level,event,detail,created_at AS "createdAt" FROM activity_logs ORDER BY created_at DESC LIMIT 20`)
  ]);
  res.json({ activePages: pages.rows[0].total, jobs: jobs.rows, recentActivity: logs.rows });
});

router.get('/api/oauth/meta/start', async (_req, res) => {
  try {
    const state = crypto.randomBytes(24).toString('hex');
    await pool.query(`INSERT INTO app_config(config_key,encrypted_value) VALUES('meta_oauth_state',$1)
      ON CONFLICT(config_key) DO UPDATE SET encrypted_value=EXCLUDED.encrypted_value,updated_at=NOW()`, [encryptSecret(state)]);
    res.json({ url: metaOAuthStart(state), state });
  } catch (e) { res.status(503).json({ error: e instanceof Error ? e.message : 'Meta OAuth chưa cấu hình.' }); }
});

router.get('/api/oauth/meta/callback', async (req, res) => {
  const code=String(req.query.code??''); const state=String(req.query.state??'');
  if (!code || !state) return res.status(400).send('Meta OAuth thiếu code/state.');
  try {
    const saved=await pool.query("SELECT encrypted_value FROM app_config WHERE config_key='meta_oauth_state'");
    if (!saved.rowCount || decryptSecret(saved.rows[0].encrypted_value)!==state) return res.status(403).send('OAuth state không hợp lệ hoặc đã hết phiên. Hãy bắt đầu kết nối lại.');
    await pool.query("DELETE FROM app_config WHERE config_key='meta_oauth_state'");
    const appId=process.env.META_APP_ID??''; const secret=process.env.META_APP_SECRET??''; const redirect=process.env.META_REDIRECT_URI??'';
    if (!appId || !secret || !redirect) return res.status(503).send('Meta OAuth chưa cấu hình đầy đủ.');
    const tokenUrl=new URL(`https://graph.facebook.com/${process.env.META_GRAPH_VERSION??'v23.0'}/oauth/access_token`);
    tokenUrl.searchParams.set('client_id',appId); tokenUrl.searchParams.set('client_secret',secret); tokenUrl.searchParams.set('redirect_uri',redirect); tokenUrl.searchParams.set('code',code);
    const tokenResp=await fetch(tokenUrl,{signal:AbortSignal.timeout(20000)}); const tokenData=await tokenResp.json() as any;
    if (!tokenResp.ok || !tokenData.access_token) throw new Error(tokenData?.error?.message??'Không đổi được OAuth code thành access token.');
    const pagesUrl=new URL(`https://graph.facebook.com/${process.env.META_GRAPH_VERSION??'v23.0'}/me/accounts`);
    pagesUrl.searchParams.set('fields','id,name,access_token,tasks'); pagesUrl.searchParams.set('access_token',tokenData.access_token);
    const pagesResp=await fetch(pagesUrl,{signal:AbortSignal.timeout(20000)}); const pagesData=await pagesResp.json() as any;
    if (!pagesResp.ok) throw new Error(pagesData?.error?.message??'Không lấy được danh sách Fanpage.');
    let count=0;
    for (const page of (pagesData.data??[])) {
      if (!page.id || !page.access_token) continue;
      await pool.query(`INSERT INTO social_pages(page_id,name,encrypted_access_token,connection_status,last_checked_at)
        VALUES($1,$2,$3,'connected',NOW()) ON CONFLICT(page_id) DO UPDATE SET name=EXCLUDED.name,
        encrypted_access_token=EXCLUDED.encrypted_access_token,connection_status='connected',last_checked_at=NOW(),updated_at=NOW()`,
        [String(page.id),String(page.name??page.id),encryptSecret(String(page.access_token))]); count++;
    }
    res.status(200).send(`<html><meta charset="utf-8"><body style="font-family:system-ui;padding:2rem"><h2>Kết nối Meta hoàn tất</h2><p>Đã đồng bộ ${count} Fanpage. Có thể đóng cửa sổ này và quay lại ứng dụng.</p></body></html>`);
  } catch(e) { res.status(502).send(`Không thể hoàn tất Meta OAuth: ${e instanceof Error ? e.message : 'lỗi không xác định'}`); }
});


// AI topic discovery using Gemini grounding / Google Search. Results are stored for deduplication and review.
router.post('/api/topics/research', async (req, res) => {
  const niche = String(req.body?.niche ?? '').trim();
  const count = Math.max(1, Math.min(15, Number(req.body?.count) || 8));
  if (niche.length < 2 || niche.length > 500) return res.status(400).json({ error: 'Ngách nội dung phải từ 2 đến 500 ký tự.' });
  try {
    await assertAiBudget();
    const ideas = await researchTopics(niche, count);
    await recordAiUsage('research_topics');
    for (const idea of ideas) {
      await pool.query(`INSERT INTO topic_ideas(id,topic,rationale,score,sources) VALUES($1,$2,$3,$4,$5)
        ON CONFLICT DO NOTHING`, [crypto.randomUUID(), idea.topic, idea.rationale, idea.score, JSON.stringify(idea.sources)]);
    }
    res.json({ ideas });
  } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Không nghiên cứu được chủ đề.' }); }
});
router.get('/api/topics', async (_req, res) => {
  const r = await pool.query(`SELECT id,topic,rationale,score,sources,status,created_at AS "createdAt" FROM topic_ideas ORDER BY created_at DESC LIMIT 100`);
  res.json({ ideas: r.rows });
});
router.post('/api/topics/:id/generate', async (req, res) => {
  const found = await pool.query('SELECT topic FROM topic_ideas WHERE id=$1', [req.params.id]);
  if (!found.rowCount) return res.status(404).json({ error: 'Không tìm thấy ý tưởng.' });
  try {
    await assertAiBudget();
    const generated = await generateContent(found.rows[0].topic, String(req.body?.style ?? 'Facebook, dễ đọc, có dẫn chứng'));
    await recordAiUsage('generate_from_topic');
    const body = String(generated.body ?? '').trim();
    if (!body) return res.status(502).json({ error: 'AI không tạo được nội dung.' });
    const title = String(generated.title ?? found.rows[0].topic).trim(); const id = crypto.randomUUID(); const fp = fingerprint(`${title}\n${body}`);
    const saved = await pool.query(`INSERT INTO content_items(id,topic,title,body,status,source_references,fingerprint)
      VALUES($1,$2,$3,$4,'draft',$5,$6) ON CONFLICT(fingerprint) DO UPDATE SET updated_at=NOW() RETURNING id`,
      [id, found.rows[0].topic, title, body, JSON.stringify(generated.sources ?? []), fp]);
    await pool.query(`UPDATE topic_ideas SET status='used' WHERE id=$1`, [req.params.id]);
    const autoJobs = await enqueueAutoPublish(saved.rows[0].id);
    res.json({ id: saved.rows[0].id, title, body, hashtags: generated.hashtags ?? [], sources: generated.sources ?? [], autoJobs });
  } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Không tạo được bài.' }); }
});

router.patch('/api/pages/:id/status', async (req, res) => {
  const active = req.body?.active;
  if (typeof active !== 'boolean') return res.status(400).json({ error: 'active phải là true hoặc false.' });
  const r = await pool.query(`UPDATE social_pages SET is_active=$2,updated_at=NOW() WHERE id=$1 RETURNING id,page_id AS "pageId",name,is_active AS active`, [req.params.id, active]);
  if (!r.rowCount) return res.status(404).json({ error: 'Không tìm thấy Fanpage.' });
  res.json({ page: r.rows[0] });
});
router.delete('/api/pages/:id', async (req, res) => {
  const r = await pool.query(`UPDATE social_pages SET is_active=false,updated_at=NOW() WHERE id=$1 RETURNING id`, [req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Không tìm thấy Fanpage.' });
  res.json({ ok: true, message: 'Fanpage đã được tạm dừng, token được giữ lại để có thể khôi phục.' });
});

router.get('/api/insights/:pageId', async (req, res) => {
  const page = await pool.query('SELECT page_id,encrypted_access_token FROM social_pages WHERE page_id=$1', [req.params.pageId]);
  if (!page.rowCount) return res.status(404).json({ error: 'Không tìm thấy Fanpage.' });
  const until = String(req.query.until ?? new Date().toISOString().slice(0,10));
  const since = String(req.query.since ?? new Date(Date.now()-6*86400000).toISOString().slice(0,10));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(since) || !/^\d{4}-\d{2}-\d{2}$/.test(until) || since > until) return res.status(400).json({ error: 'Khoảng ngày không hợp lệ.' });
  try {
    const data = await getPageInsights(page.rows[0].page_id, page.rows[0].encrypted_access_token, since, until);
    await pool.query(`INSERT INTO page_insights_cache(page_id,period_start,period_end,metrics) VALUES($1,$2,$3,$4)
      ON CONFLICT(page_id,period_start,period_end) DO UPDATE SET metrics=EXCLUDED.metrics,fetched_at=NOW()`, [req.params.pageId,since,until,JSON.stringify(data)]);
    res.json({ pageId: req.params.pageId, since, until, data });
  } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Không lấy được insights. Kiểm tra quyền Meta.' }); }
});

router.get('/api/automation', async (_req, res) => {
  const r = await pool.query('SELECT rule_key AS key,settings,enabled,updated_at AS "updatedAt" FROM automation_rules ORDER BY rule_key');
  res.json({ rules: r.rows });
});
router.put('/api/automation/:key', async (req, res) => {
  const allowed = new Set(['auto_publish','auto_reply_comments','comment_filter','daily_report','budget_guard','duplicate_guard','optimal_time']);
  if (!allowed.has(req.params.key)) return res.status(400).json({ error: 'Loại tự động hóa không hợp lệ.' });
  const enabled = req.body?.enabled;
  const settings = req.body?.settings && typeof req.body.settings === 'object' ? req.body.settings : {};
  if (typeof enabled !== 'boolean') return res.status(400).json({ error: 'enabled phải là true hoặc false.' });
  await pool.query(`INSERT INTO automation_rules(rule_key,settings,enabled) VALUES($1,$2,$3)
    ON CONFLICT(rule_key) DO UPDATE SET settings=EXCLUDED.settings,enabled=EXCLUDED.enabled,updated_at=NOW()`, [req.params.key,JSON.stringify(settings),enabled]);
  res.json({ key: req.params.key, enabled, settings });
});

router.post('/api/comments/:id/reply', async (req, res) => {
  const message = String(req.body?.message ?? '').trim();
  if (!message || message.length > 8000) return res.status(400).json({ error: 'Nội dung phản hồi phải từ 1 đến 8000 ký tự.' });
  const event = await pool.query('SELECT id,page_id FROM comment_events WHERE id=$1', [req.params.id]);
  if (!event.rowCount) return res.status(404).json({ error: 'Không tìm thấy bình luận đã đồng bộ. Webhook Meta phải được cấu hình trước.' });
  const page = await pool.query('SELECT encrypted_access_token FROM social_pages WHERE page_id=$1 AND is_active=true', [event.rows[0].page_id]);
  if (!page.rowCount) return res.status(404).json({ error: 'Fanpage không hoạt động.' });
  try {
    const result = await replyToComment(req.params.id, page.rows[0].encrypted_access_token, message);
    await pool.query(`UPDATE comment_events SET status='replied',reply_text=$2,updated_at=NOW() WHERE id=$1`, [req.params.id,message]);
    res.json({ ok: true, result });
  } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Không gửi được phản hồi.' }); }
});

router.post('/api/ab-tests', async (req, res) => {
  const contentId = String(req.body?.contentId ?? ''); const pageId = String(req.body?.pageId ?? '');
  const a = String(req.body?.variantA ?? '').trim(); const b = String(req.body?.variantB ?? '').trim();
  if (!contentId || !pageId || a.length < 3 || b.length < 3 || a === b) return res.status(400).json({ error: 'Cần bài viết, Fanpage và hai biến thể tiêu đề khác nhau.' });
  const id = crypto.randomUUID();
  const r = await pool.query(`INSERT INTO ab_tests(id,content_id,page_id,variant_a,variant_b) VALUES($1,$2,$3,$4,$5) RETURNING *`, [id,contentId,pageId,a,b]);
  res.status(201).json({ test: r.rows[0], note: 'Đã lưu thử nghiệm. Không tự đăng biến thể; cần duyệt và đo lường riêng để tránh đăng trùng.' });
});
router.get('/api/ab-tests', async (_req,res) => { const r=await pool.query('SELECT * FROM ab_tests ORDER BY created_at DESC LIMIT 100'); res.json({tests:r.rows}); });

router.get('/api/usage', async (req,res) => {
  const days = Math.max(1,Math.min(90,Number(req.query.days)||30));
  const [totals,byProvider] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(estimated_cost),0)::numeric(12,4) AS cost,COUNT(*)::int AS calls FROM ai_usage WHERE created_at>NOW()-($1::text||' days')::interval`,[days]),
    pool.query(`SELECT provider,operation,COUNT(*)::int AS calls,COALESCE(SUM(estimated_cost),0)::numeric(12,4) AS cost FROM ai_usage WHERE created_at>NOW()-($1::text||' days')::interval GROUP BY provider,operation ORDER BY cost DESC`,[days])
  ]);
  const rule=await pool.query("SELECT settings,enabled FROM automation_rules WHERE rule_key='budget_guard'");
  res.json({days,...totals.rows[0],byProvider:byProvider.rows,budgetGuard:rule.rows[0]??{enabled:false,settings:{}}});
});

router.get('/api/activity', async (req,res) => {
  const limit=Math.max(1,Math.min(200,Number(req.query.limit)||50));
  const r=await pool.query('SELECT id,level,event,detail,created_at AS "createdAt" FROM activity_logs ORDER BY created_at DESC LIMIT $1',[limit]);
  res.json({events:r.rows});
});

router.get('/api/content', async (_req,res) => {
  const r=await pool.query(`SELECT id,topic,title,body,status,media_type AS "mediaType",media_url AS "mediaUrl",source_references AS sources,created_at AS "createdAt" FROM content_items ORDER BY created_at DESC LIMIT 200`);
  res.json({content:r.rows});
});
router.delete('/api/content/:id', async (req,res) => {
  const check=await pool.query("SELECT id FROM publishing_jobs WHERE content_id=$1 AND status IN ('queued','scheduled','publishing','published') LIMIT 1",[req.params.id]);
  if (check.rowCount) return res.status(409).json({error:'Không thể xoá nội dung đã đưa vào lịch hoặc đã đăng.'});
  const r=await pool.query("DELETE FROM content_items WHERE id=$1 AND status <> 'published' RETURNING id",[req.params.id]);
  if (!r.rowCount) return res.status(404).json({error:'Không tìm thấy nội dung hoặc nội dung đã đăng.'});
  res.json({ok:true});
});


router.get('/api/webhook/meta', (req,res) => {
  const verify=process.env.META_WEBHOOK_VERIFY_TOKEN??'';
  if (verify && req.query['hub.mode']==='subscribe' && req.query['hub.verify_token']===verify) return res.status(200).send(String(req.query['hub.challenge']??''));
  return res.sendStatus(403);
});
router.post('/api/webhook/meta', async (req,res) => {
  const appSecret=process.env.META_APP_SECRET??'';
  const signature=String(req.header('x-hub-signature-256')??'');
  // Signature validation requires the exact raw request bytes. If raw-body middleware is not enabled, fail closed.
  const raw=(req as any).rawBody as Buffer|undefined;
  if (!appSecret || !raw || !signature.startsWith('sha256=')) return res.sendStatus(401);
  const expected='sha256='+crypto.createHmac('sha256',appSecret).update(raw).digest('hex');
  const a=Buffer.from(signature); const b=Buffer.from(expected);
  if (a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.sendStatus(401);
  try {
    const body=req.body as any;
    for (const entry of (body?.entry??[])) {
      const pageId=String(entry.id??'');
      for (const change of (entry.changes??[])) {
        if (change.field!=='feed') continue;
        const v=change.value??{}; const commentId=String(v.comment_id??v.post_id??'');
        if (!commentId || !v.message) continue;
        const commentText=String(v.message).slice(0,8000);
        const spam=/\b(earn money fast|crypto investment|click here|whatsapp me|airdrop|giveaway winner)\b/i.test(commentText);
        const sensitive=/\b(sue you|lawyer|lawsuit|medical emergency|suicide|password|bank account)\b/i.test(commentText);
        const inserted=await pool.query(`INSERT INTO comment_events(id,page_id,post_id,commenter_id,message,classification,status) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(id) DO NOTHING RETURNING id`,
          [commentId,pageId,String(v.post_id??''),String(v.from?.id??''),commentText,spam?'spam':sensitive?'needs_human':'normal',spam?'filtered':sensitive?'needs_human':'new']);
        if (inserted.rowCount && !spam && !sensitive) {
          const rule=await pool.query("SELECT enabled FROM automation_rules WHERE rule_key='auto_reply_comments'");
          if (rule.rows[0]?.enabled) {
            try {
              const page=await pool.query('SELECT name,encrypted_access_token FROM social_pages WHERE page_id=$1 AND is_active=true',[pageId]);
              if (page.rowCount) {
                const reply=await generateCommentReply(commentText,page.rows[0].name);
                if (reply && reply!=='NEED_HUMAN') {
                  await replyToComment(commentId,page.rows[0].encrypted_access_token,reply);
                  await pool.query("UPDATE comment_events SET status='replied',reply_text=$2,updated_at=NOW() WHERE id=$1",[commentId,reply]);
                } else await pool.query("UPDATE comment_events SET status='needs_human',updated_at=NOW() WHERE id=$1",[commentId]);
              }
            } catch (replyErr) { await pool.query("INSERT INTO activity_logs(level,event,detail) VALUES('error','auto_comment_reply_failed',$1)",[JSON.stringify({commentId,message:replyErr instanceof Error?replyErr.message:'unknown'})]); }
          }
        }
      }
      for (const messaging of (entry.messaging??[])) {
        const message=messaging.message; if (!message?.text || !message?.mid) continue;
        await pool.query(`INSERT INTO inbox_events(id,page_id,sender_id,message) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING`,
          [String(message.mid),pageId,String(messaging.sender?.id??''),String(message.text).slice(0,8000)]);
      }
    }
    res.sendStatus(200);
  } catch(e) { await pool.query("INSERT INTO activity_logs(level,event,detail) VALUES('error','meta_webhook_failed',$1)",[JSON.stringify({message:e instanceof Error?e.message:'unknown'})]); res.sendStatus(500); }
});
router.get('/api/comments', async (req,res) => {
  const status=String(req.query.status??'new');
  const r=await pool.query(`SELECT id,page_id AS "pageId",post_id AS "postId",commenter_id AS "commenterId",message,classification,reply_text AS "replyText",status,created_at AS "createdAt" FROM comment_events WHERE ($1='all' OR status=$1) ORDER BY created_at DESC LIMIT 200`,[status]);
  res.json({comments:r.rows});
});
router.get('/api/inbox', async (_req,res) => {
  const r=await pool.query(`SELECT id,page_id AS "pageId",sender_id AS "senderId",message,status,created_at AS "createdAt" FROM inbox_events ORDER BY created_at DESC LIMIT 200`);
  res.json({messages:r.rows,note:'Đồng bộ webhook cần bật Messenger Webhooks và quyền Meta phù hợp. Gửi trả lời Messenger cần endpoint/permission riêng đã được Meta xét duyệt.'});
});


router.put('/api/config/:key', async (req,res) => {
  const allowed=new Set(['gemini_api_key','default_niche','default_style','ai_monthly_budget_usd','report_email','timezone']);
  if (!allowed.has(req.params.key) || req.params.key==='gemini_api_key') return res.status(400).json({error:'Key cấu hình không hợp lệ. Gemini dùng endpoint riêng.'});
  const value=String(req.body?.value??'').trim();
  if (value.length>2000) return res.status(400).json({error:'Giá trị cấu hình quá dài.'});
  await pool.query(`INSERT INTO app_config(config_key,encrypted_value) VALUES($1,$2)
    ON CONFLICT(config_key) DO UPDATE SET encrypted_value=EXCLUDED.encrypted_value,updated_at=NOW()`,[req.params.key,encryptSecret(value)]);
  res.json({ok:true,key:req.params.key});
});
router.get('/api/config/:key', async (req,res) => {
  const allowed=new Set(['default_niche','default_style','ai_monthly_budget_usd','report_email','timezone']);
  if (!allowed.has(req.params.key)) return res.status(400).json({error:'Không cho phép đọc key này.'});
  const r=await pool.query('SELECT encrypted_value FROM app_config WHERE config_key=$1',[req.params.key]);
  res.json({key:req.params.key,configured:!!r.rowCount,value:r.rowCount?decryptSecret(r.rows[0].encrypted_value):''});
});

router.post('/api/posts/bulk', async (req,res) => {
  const contentId=String(req.body?.contentId??''); const pageIds=Array.isArray(req.body?.pageIds)?[...new Set(req.body.pageIds.map((x:any)=>String(x)))]:[];
  const scheduledAt=req.body?.scheduledAt?new Date(req.body.scheduledAt):null;
  if (!contentId || pageIds.length<1 || pageIds.length>50 || (scheduledAt&&Number.isNaN(scheduledAt.getTime()))) return res.status(400).json({error:'Cần contentId, 1-50 Page ID và thời gian hợp lệ.'});
  const content=await pool.query('SELECT id FROM content_items WHERE id=$1',[contentId]);
  if (!content.rowCount) return res.status(404).json({error:'Không tìm thấy nội dung.'});
  const pages=await pool.query('SELECT page_id FROM social_pages WHERE page_id=ANY($1::text[]) AND is_active=true',[pageIds]);
  if (pages.rowCount!==pageIds.length) return res.status(400).json({error:'Có Fanpage không tồn tại hoặc đang tạm dừng.'});
  const results=[];
  for (const pageId of pageIds) {
    const id=crypto.randomUUID(); const future=!!scheduledAt&&scheduledAt.getTime()>Date.now();
    await pool.query('INSERT INTO publishing_jobs(id,content_id,page_id,scheduled_at,status) VALUES($1,$2,$3,$4,$5)',[id,contentId,pageId,scheduledAt,future?'scheduled':'queued']);
    await publishQueue.add('publish',{jobId:id},{jobId:id,delay:future?Math.max(0,scheduledAt!.getTime()-Date.now()):0,attempts:3,backoff:{type:'exponential',delay:5000},removeOnComplete:1000,removeOnFail:2000});
    results.push({id,pageId,status:future?'scheduled':'queued'});
  }
  res.status(201).json({jobs:results});
});

router.post('/api/posts/:id/cancel', async (req,res) => {
  const r=await pool.query("UPDATE publishing_jobs SET status='cancelled',updated_at=NOW() WHERE id=$1 AND status IN ('queued','scheduled','failed') RETURNING id",[req.params.id]);
  if (!r.rowCount) return res.status(409).json({error:'Không tìm thấy tác vụ hoặc tác vụ đã bắt đầu/đăng xong.'});
  try { await publishQueue.remove(req.params.id); } catch {}
  res.json({ok:true,status:'cancelled'});
});

router.get('/api/reports/daily', async (req,res) => {
  const day=String(req.query.date??new Date().toISOString().slice(0,10));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return res.status(400).json({error:'date cần định dạng YYYY-MM-DD.'});
  const [jobs,pages,comments,usage]=await Promise.all([
    pool.query(`SELECT status,COUNT(*)::int AS count FROM publishing_jobs WHERE created_at >= $1::date AND created_at < $1::date + interval '1 day' GROUP BY status`,[day]),
    pool.query('SELECT COUNT(*)::int AS active FROM social_pages WHERE is_active=true'),
    pool.query(`SELECT status,COUNT(*)::int AS count FROM comment_events WHERE created_at >= $1::date AND created_at < $1::date + interval '1 day' GROUP BY status`,[day]),
    pool.query(`SELECT COUNT(*)::int AS calls,COALESCE(SUM(estimated_cost),0)::numeric(12,4) AS estimated_cost FROM ai_usage WHERE created_at >= $1::date AND created_at < $1::date + interval '1 day'`,[day])
  ]);
  res.json({date:day,activePages:pages.rows[0].active,publishing:jobs.rows,comments:comments.rows,aiUsage:usage.rows[0]});
});

router.put('/api/content/:id', async (req,res) => {
  const title=String(req.body?.title??'').trim(); const body=String(req.body?.body??'').trim();
  if (title.length>500 || body.length<1 || body.length>50000) return res.status(400).json({error:'Tiêu đề tối đa 500 ký tự, nội dung từ 1 đến 50000 ký tự.'});
  const fp=fingerprint(`${title}\n${body}`);
  const r=await pool.query(`UPDATE content_items SET title=$2,body=$3,fingerprint=$4,updated_at=NOW() WHERE id=$1 AND status <> 'published' RETURNING id,title,body,status`,[req.params.id,title,body,fp]);
  if (!r.rowCount) return res.status(404).json({error:'Không tìm thấy bản nháp hoặc bài đã đăng.'});
  res.json({content:r.rows[0]});
});

router.post('/api/inbox/:id/reply', async (req,res) => {
  const message=String(req.body?.message??'').trim();
  if (!message || message.length>2000) return res.status(400).json({error:'Tin nhắn phải từ 1 đến 2000 ký tự.'});
  const event=await pool.query('SELECT id,page_id,sender_id FROM inbox_events WHERE id=$1',[req.params.id]);
  if (!event.rowCount) return res.status(404).json({error:'Không tìm thấy tin nhắn inbox.'});
  const page=await pool.query('SELECT encrypted_access_token FROM social_pages WHERE page_id=$1 AND is_active=true',[event.rows[0].page_id]);
  if (!page.rowCount) return res.status(404).json({error:'Fanpage không hoạt động.'});
  try {
    const result=await sendMessengerMessage(event.rows[0].page_id,page.rows[0].encrypted_access_token,event.rows[0].sender_id,message);
    await pool.query("UPDATE inbox_events SET status='replied' WHERE id=$1",[req.params.id]); res.json({ok:true,result});
  } catch(e) { res.status(502).json({error:e instanceof Error?e.message:'Không gửi được tin nhắn. Kiểm tra pages_messaging và cửa sổ 24 giờ của Meta.'}); }
});

router.get('/api/reports/weekly', async (_req,res) => {
  const [jobs,pages,comments,usage,insights]=await Promise.all([
    pool.query(`SELECT status,COUNT(*)::int AS count FROM publishing_jobs WHERE created_at>=NOW()-INTERVAL '7 days' GROUP BY status`),
    pool.query('SELECT COUNT(*)::int AS active FROM social_pages WHERE is_active=true'),
    pool.query(`SELECT status,COUNT(*)::int AS count FROM comment_events WHERE created_at>=NOW()-INTERVAL '7 days' GROUP BY status`),
    pool.query(`SELECT COUNT(*)::int AS calls,COALESCE(SUM(estimated_cost),0)::numeric(12,4) AS estimated_cost FROM ai_usage WHERE created_at>=NOW()-INTERVAL '7 days'`),
    pool.query(`SELECT page_id,period_start,period_end,metrics,fetched_at FROM page_insights_cache WHERE period_end>=CURRENT_DATE-7 ORDER BY fetched_at DESC LIMIT 100`)
  ]);
  res.json({period:'last_7_days',generatedAt:new Date().toISOString(),activePages:pages.rows[0].active,publishing:jobs.rows,comments:comments.rows,aiUsage:usage.rows[0],cachedInsights:insights.rows});
});
