import { Worker } from 'bullmq';
import { URL } from 'node:url';
import { pool } from './db.js';
import { publishText, publishPhoto, publishVideo } from './meta.js';

export function startWorker() {
  const redisUrl = new URL(process.env.REDIS_URL ?? 'redis://localhost:6379');
  const worker = new Worker('publishing', async job => {
    const { jobId } = job.data as { jobId: string };
    const result = await pool.query(
      `SELECT j.id, j.page_id, c.body, c.media_type, c.media_url, c.image_url, p.encrypted_access_token
       FROM publishing_jobs j JOIN content_items c ON c.id=j.content_id
       JOIN social_pages p ON p.page_id=j.page_id
       WHERE j.id=$1 AND p.is_active=true`,
      [jobId]
    );
    if (!result.rowCount) throw new Error('Không tìm thấy tác vụ hoặc Fanpage đang bị tạm dừng.');
    const row = result.rows[0];
    await pool.query(`UPDATE publishing_jobs SET status='publishing', attempts=attempts+1, updated_at=NOW() WHERE id=$1`, [jobId]);
    try {
      const mediaUrl = row.media_url || row.image_url;
      let published: { id: string; post_id?: string };
      if (row.media_type === 'image' && mediaUrl) published = await publishPhoto(row.page_id, row.encrypted_access_token, row.body, mediaUrl);
      else if (row.media_type === 'video' && mediaUrl) published = await publishVideo(row.page_id, row.encrypted_access_token, row.body, mediaUrl);
      else if (row.media_type === 'text' || !row.media_type) published = await publishText(row.page_id, row.encrypted_access_token, row.body);
      else throw new Error('Bài media cần media_url HTTPS hợp lệ và media_type image/video.');
      await pool.query(`UPDATE publishing_jobs SET status='published', facebook_post_id=$2, error_message=NULL, updated_at=NOW() WHERE id=$1`, [jobId, published.id]);
      await pool.query(`UPDATE content_items SET status='published', updated_at=NOW() WHERE id=(SELECT content_id FROM publishing_jobs WHERE id=$1)`, [jobId]);
      await pool.query('INSERT INTO activity_logs(level,event,detail) VALUES($1,$2,$3)', ['info', 'post_published', JSON.stringify({ jobId, postId: published.id })]);
      return published;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Lỗi không xác định';
      await pool.query(`UPDATE publishing_jobs SET status='failed', error_message=$2, updated_at=NOW() WHERE id=$1`, [jobId, message]);
      await pool.query('INSERT INTO activity_logs(level,event,detail) VALUES($1,$2,$3)', ['error', 'post_publish_failed', JSON.stringify({ jobId, message })]);
      throw err;
    }
  }, {
    connection: {
      host: redisUrl.hostname, port: Number(redisUrl.port || 6379),
      username: redisUrl.username || undefined, password: redisUrl.password || undefined,
      maxRetriesPerRequest: null
    },
    concurrency: 3
  });
  worker.on('failed', (job, err) => console.error(`Publishing job ${job?.id} failed:`, err.message));
  worker.on('error', err => console.error('BullMQ worker error:', err.message));
}
