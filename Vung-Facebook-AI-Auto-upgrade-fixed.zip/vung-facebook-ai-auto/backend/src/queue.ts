import { Queue } from 'bullmq';
import { URL } from 'node:url';
const redisUrl = new URL(process.env.REDIS_URL ?? 'redis://localhost:6379');
export const publishQueue = new Queue('publishing', {
  connection: {
    host: redisUrl.hostname,
    port: Number(redisUrl.port || 6379),
    username: redisUrl.username || undefined,
    password: redisUrl.password || undefined,
    maxRetriesPerRequest: null
  }
});
