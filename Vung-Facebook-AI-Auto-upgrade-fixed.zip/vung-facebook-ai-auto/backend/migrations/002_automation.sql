CREATE TABLE IF NOT EXISTS topic_ideas (
 id UUID PRIMARY KEY, topic TEXT NOT NULL, rationale TEXT NOT NULL DEFAULT '', score NUMERIC(5,2) NOT NULL DEFAULT 0,
 sources JSONB NOT NULL DEFAULT '[]'::jsonb, status TEXT NOT NULL DEFAULT 'new', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS page_insights_cache (
 id BIGSERIAL PRIMARY KEY, page_id TEXT NOT NULL, period_start DATE NOT NULL, period_end DATE NOT NULL,
 metrics JSONB NOT NULL DEFAULT '{}'::jsonb, fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(page_id,period_start,period_end)
);
CREATE TABLE IF NOT EXISTS automation_rules (
 id BIGSERIAL PRIMARY KEY, rule_key TEXT NOT NULL UNIQUE, settings JSONB NOT NULL DEFAULT '{}'::jsonb,
 enabled BOOLEAN NOT NULL DEFAULT FALSE, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS comment_events (
 id TEXT PRIMARY KEY, page_id TEXT NOT NULL, post_id TEXT, commenter_id TEXT, message TEXT NOT NULL DEFAULT '',
 classification TEXT NOT NULL DEFAULT 'unclassified', reply_text TEXT, status TEXT NOT NULL DEFAULT 'new',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS inbox_events (
 id TEXT PRIMARY KEY, page_id TEXT NOT NULL, sender_id TEXT, message TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'new', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ab_tests (
 id UUID PRIMARY KEY, content_id UUID NOT NULL REFERENCES content_items(id), page_id TEXT NOT NULL,
 variant_a TEXT NOT NULL, variant_b TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft',
 winner TEXT, results JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ai_usage (
 id BIGSERIAL PRIMARY KEY, provider TEXT NOT NULL, operation TEXT NOT NULL, estimated_cost NUMERIC(12,6) NOT NULL DEFAULT 0,
 units INTEGER NOT NULL DEFAULT 1, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS webhook_dedup (
 event_id TEXT PRIMARY KEY, received_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS publishing_jobs_due_idx ON publishing_jobs(status,scheduled_at);
CREATE INDEX IF NOT EXISTS activity_logs_created_idx ON activity_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS comment_events_status_idx ON comment_events(status,created_at DESC);
ALTER TABLE content_items ADD COLUMN IF NOT EXISTS media_type TEXT NOT NULL DEFAULT 'text';
ALTER TABLE content_items ADD COLUMN IF NOT EXISTS media_url TEXT;
ALTER TABLE content_items ADD COLUMN IF NOT EXISTS hashtags JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE content_items ADD COLUMN IF NOT EXISTS review_status TEXT NOT NULL DEFAULT 'needs_review';
CREATE UNIQUE INDEX IF NOT EXISTS topic_ideas_topic_unique ON topic_ideas (lower(topic));
