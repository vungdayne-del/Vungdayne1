# Vùng Facebook AI Auto · Upgrade 2.0

Bộ mã nguồn Android + backend để quản lý nhiều Facebook Page, tạo nội dung bằng Gemini, nghiên cứu chủ đề có Google Search grounding, lên lịch đăng, theo dõi lỗi và quản lý tích hợp Meta. ZIP này là **mã nguồn**, không phải APK đã ký hay dịch vụ đã triển khai.

## Thành phần

- `android/`: app Kotlin + Jetpack Compose, nhập URL backend/token, quản lý Fanpage, tạo nội dung và xem lịch sử. APK debug được build qua GitHub Actions.
- `backend/`: Express + TypeScript, PostgreSQL, Redis/BullMQ, AES-256-GCM mã hóa token/key ở máy chủ.
- `backend/migrations/`: migration được chạy khi backend khởi động.
- `.github/workflows/build.yml`: kiểm tra backend và build APK artifact.
- `docker-compose.yml`: PostgreSQL, Redis và backend tự khởi động lại.

## Chạy backend 24/7

1. Sao chép `backend/.env.example` thành `backend/.env`. Tạo `ENCRYPTION_KEY` bằng `openssl rand -hex 32`, `ADMIN_API_TOKEN` dài ngẫu nhiên tối thiểu 32 ký tự và mật khẩu PostgreSQL mạnh.
2. Đặt `POSTGRES_PASSWORD` trong môi trường chạy Docker, khớp với mật khẩu dùng trong `DATABASE_URL` do Compose dựng.
3. Cấu hình `GEMINI_API_KEY` hoặc nhập key từ app. Cấu hình `META_APP_ID`, `META_APP_SECRET`, `META_REDIRECT_URI` và `META_WEBHOOK_VERIFY_TOKEN` khi dùng Meta OAuth/webhook.
4. Chạy `docker compose up --build -d`. Xem log bằng `docker compose logs -f backend`.
5. Đưa HTTPS reverse proxy phía trước backend trước khi truy cập từ mạng công cộng. Không expose PostgreSQL/Redis công khai.

GitHub Actions chỉ build APK; nó **không** giữ backend chạy 24/7. Muốn tự động đăng theo lịch, backend và Redis phải chạy liên tục trên VPS/server.

## Build APK

Đưa thư mục lên GitHub, vào **Actions → Build Android APK and test backend → Run workflow**. Tải artifact `vung-facebook-ai-auto-debug-apk`. APK debug phù hợp kiểm thử; bản phát hành cần cấu hình signing riêng. Không commit token, key, keystore hay `.env`.

## API quản trị

Mọi endpoint `/api/*` yêu cầu `Authorization: Bearer <ADMIN_API_TOKEN>`, ngoại trừ `/api/health`, callback OAuth và endpoint webhook Meta.

- Dashboard: `GET /api/health`, `GET /api/reports/overview`, `GET /api/reports/daily`, `GET /api/reports/weekly`, `GET /api/activity`
- Fanpage: `GET/POST /api/pages`, `POST /api/pages/:id/check`, `PATCH /api/pages/:id/status`, `DELETE /api/pages/:id` (tạm dừng)
- OAuth: `GET /api/oauth/meta/start`, callback `/api/oauth/meta/callback`
- AI: `POST /api/ai/generate`, `POST /api/topics/research`, `GET /api/topics`, `POST /api/topics/:id/generate`
- Nội dung: `GET /api/content`, `PATCH /api/content/:id/media`, `DELETE /api/content/:id`
- Đăng bài: `POST /api/posts`, `POST /api/posts/bulk`, `GET /api/posts`, `POST /api/posts/:id/publish`, `POST /api/posts/:id/cancel`
- Cài đặt: `GET /api/config`, `PUT /api/config/gemini`, `GET/PUT /api/config/:key`, `GET/PUT /api/automation/:key`
- Phân tích: `GET /api/insights/:pageId`, `GET /api/usage`
- Bình luận/inbox: `GET /api/comments`, `POST /api/comments/:id/reply`, `GET /api/inbox`, `POST /api/inbox/:id/reply`, webhook `/api/webhook/meta`
- A/B test tiêu đề: `POST /api/ab-tests`, `GET /api/ab-tests`

## Quy tắc media và đăng bài

Tạo nội dung bằng AI chưa tự động đăng ngay. Bài được lưu nháp; người vận hành chọn Fanpage và thời gian. Để đăng ảnh/video, gọi `PATCH /api/content/:id/media` với `mediaType=image|video` và URL HTTPS công khai mà Meta có thể tải; bài text dùng `mediaType=text`. URL không được tải lên backend, do đó phải nằm ở nơi lưu trữ có quyền truy cập phù hợp. Chỉ dùng hình/video bạn sở hữu hoặc có giấy phép.

Đăng bài qua Meta Graph API cần Page Access Token và quyền được Meta cấp. Insights, comment moderation, webhook và Messenger còn phụ thuộc quyền, subscription, app review và cấu hình webhook thực tế. Messenger inbox hiện đồng bộ event webhook để xem; gửi phản hồi Messenger chưa được bật trong bản này vì cần luồng send API/quyền được phê duyệt.

## An toàn và giới hạn cần biết

- Secret được mã hóa AES-256-GCM trong PostgreSQL; `ENCRYPTION_KEY` phải được sao lưu an toàn, nếu mất key sẽ không giải mã được secret.
- `ADMIN_API_TOKEN` là token quản trị dùng chung, không phải hệ thống đăng nhập nhiều người dùng. Giữ riêng tư, dùng HTTPS và giới hạn IP qua reverse proxy.
- Webhook Meta kiểm tra `X-Hub-Signature-256`; Meta Developer Console phải trỏ đúng callback và bật các field cần thiết.
- Tự động trả lời bình luận có thể bật bằng `PUT /api/automation/auto_reply_comments` với `enabled=true`; bật `auto_publish` với `settings: {"pageIds": ["PAGE_ID"], "requireApproval": false}` mới cho phép AI tạo bài rồi đưa thẳng vào hàng đợi đăng. Mặc định auto-publish tắt. Bộ lọc từ khóa chuyển các trường hợp nhạy cảm cho người thật. Kiểm thử trước khi bật trên Page thật. Messenger có endpoint phản hồi nhưng chỉ hoạt động khi Meta cấp `pages_messaging` và cho phép gửi trong cửa sổ/chính sách áp dụng. Không dùng bot để spam hoặc né giới hạn Meta.
- A/B test hiện lưu hai biến thể và kết quả để theo dõi; không tự đăng hai biến thể hay tự kết luận người thắng khi chưa có dữ liệu.
- Bộ theo dõi AI usage ghi số lượt gọi và chi phí ước tính theo `AI_ESTIMATED_COST_PER_CALL_USD`. Bật `budget_guard` bằng `PUT /api/automation/budget_guard` với `settings: {"monthlyBudgetUsd": 10, "estimatedCostPerCallUsd": 0.002}` để dừng tác vụ trước khi vượt ngân sách ước tính. Phải cập nhật theo giá/usage thật của nhà cung cấp; đây không phải hóa đơn chính xác.
- Retry có thể an toàn với lỗi trước khi Meta nhận bài, nhưng timeout sau khi Meta đã nhận request vẫn cần đối soát thủ công để loại trừ bài đăng trùng. Kiểm tra trạng thái trước khi bấm đăng lại.

## Kiểm thử

```bash
cd backend
npm install
npm test
npm run build
```

Chạy test/build trong môi trường có Node.js 22 và quyền tải npm dependencies. Trước khi triển khai thật, cần kiểm thử với Meta app/Page test và quyền API thực tế.
